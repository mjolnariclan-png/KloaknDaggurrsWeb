param([string]$Repo="C:\Users\caspe\GitHub\KloaknDaggurrsWeb")
$ErrorActionPreference="Stop"
Write-Host "============================================================"
Write-Host " KLOAK & DAGGURRS - UNIFIED RAILWAY V1 INSTALLER"
Write-Host "============================================================"
if(!(Test-Path "$Repo\index.html")){ throw "K&D repo not found: $Repo" }
$stamp=Get-Date -Format "yyyyMMdd-HHmmss"
$backup=Join-Path $Repo "_backup_unified_railway_$stamp"
New-Item -ItemType Directory -Force $backup | Out-Null
foreach($f in @('package.json','server-production.js','railway.json')){ if(Test-Path (Join-Path $Repo $f)){ Copy-Item (Join-Path $Repo $f) $backup -Force } }
if(Test-Path "$Repo\game"){ Copy-Item "$Repo\game" "$backup\game" -Recurse -Force }
$payload=Join-Path $PSScriptRoot 'payload'
Copy-Item "$payload\*" $Repo -Recurse -Force
# Include hidden env example separately
Copy-Item "$payload\.env.example" "$Repo\.env.example" -Force
# Append gitignore safely
$gi=Join-Path $Repo '.gitignore'; if(!(Test-Path $gi)){New-Item $gi -ItemType File|Out-Null}
$adds=Get-Content "$payload\.gitignore.additions"
$current=Get-Content $gi -ErrorAction SilentlyContinue
foreach($line in $adds){ if($line -and $current -notcontains $line){ Add-Content $gi $line } }
# Point current Battle Arena launcher at same-origin /game/
$appjs=Join-Path $Repo 'assets\js\app.js'
if(Test-Path $appjs){
  $txt=Get-Content $appjs -Raw
  $txt=$txt.Replace('href="http://localhost:3005" target="_blank"','href="/game/"')
  $txt=$txt.Replace("href='http://localhost:3005' target='_blank'","href='/game/'")
  Set-Content $appjs $txt -Encoding UTF8
}
# remove local bulky artifacts; backup first if present
if(Test-Path "$Repo\test game.zip"){ Copy-Item "$Repo\test game.zip" $backup -Force; Remove-Item "$Repo\test game.zip" -Force }
if(Test-Path "$Repo\node_modules"){ Remove-Item "$Repo\node_modules" -Recurse -Force }
Write-Host "[PASS] Unified Railway payload installed"
Write-Host "Backup: $backup"
Write-Host "NEXT: cd $Repo"
Write-Host "      npm install"
Write-Host "      npm run check"
Write-Host "      git add -A && git status"
